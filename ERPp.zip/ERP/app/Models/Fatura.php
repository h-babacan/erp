<?php

namespace App\Models;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;


class CreateFaturalarTable extends Migration
{
    public function up()
    {
        Schema::create('faturalar', function (Blueprint $table) {
            $table->id();
            $table->string('fatura_no');
            $table->decimal('tutar', 10, 2);
            $table->timestamps(); // Oluşturulma ve güncelleme tarihlerini otomatik olarak ekler
        });
    }

    public function down()
    {
        Schema::dropIfExists('faturalar');
    }
}
