<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ErpController extends Controller
{
    public function site()
    {

        return view('tema');
    }
}
